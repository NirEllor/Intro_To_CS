def secret_function():
    print("My username is 'ellorw.nir' and I found the string 'ddXsjBXjPrlK' in the submission response.")